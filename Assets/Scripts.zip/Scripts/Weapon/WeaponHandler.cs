using UnityEngine;
using Subvrsive.Combat.Weapons;
using Subvrsive.Combat.Characters;

namespace Subvrsive.Combat.Characters
{
    public class WeaponHandler : MonoBehaviour
    {
        public Transform handSocket;
        public WeaponInventory weaponInventory;

        private Gun currentGun;

        void Start()
        {
            EquipRandomWeapon();
        }

        void EquipRandomWeapon()
        {
            if (weaponInventory == null || weaponInventory.weapons.Count == 0) return;

            int index = Random.Range(0, weaponInventory.weapons.Count);
            var weaponData = weaponInventory.weapons[index];

            GameObject weaponObj = Instantiate(weaponData.weaponPrefab, handSocket.position, handSocket.rotation, handSocket);
            currentGun = weaponObj.GetComponent<Gun>();
        }

        public void TryShoot(CharacterHealth target)
        {
            currentGun?.TryShoot(target);
        }

        //check with enimy is visisble or not with raycast and also draw raycast
        public bool CanShoot(CharacterHealth target)
        {
            if (target == null || !target.IsAlive()) return false;
            Vector3 direction = target.transform.position - transform.position;
            float distance = Vector3.Distance(transform.position, target.transform.position);
            RaycastHit hit;
            Vector3 raycastOffcet =new Vector3(0, 0.5f, 0);
            if (Physics.Raycast(transform.position + raycastOffcet, direction.normalized, out hit, distance))
            {
                Debug.DrawLine(transform.position + raycastOffcet, hit.point, Color.red);
                if (hit.transform == target.transform)
                {
                    return true;
                }
            }
            return false;
        }
    }
}
